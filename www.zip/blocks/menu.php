<div class="navbar navbar-default">
	<div class="container" >
	    <div class="navbar-header">
	        
		    <div class="navbar-collapse collapse">
		        <ul class="nav navbar-nav" >
		          
		         	<li ><a href="index.php" class="<?=$index?>">О нас</a></li>
		        	 <li>
		          		<a class="<?=$shop?>" href="shop.php" ">Ассортимент</a>
		          		<ul class="submenu" style="z-index: 100">
			          		<li class="<?=$it01?>"><a href="item01.php">Швейная фурнитура</a></li>
			          		<li class="<?=$it02?>"><a href="item02.php">Товары для дома</a></li>
			          		<li class="<?=$it03?>"><a href="item03.php">Бытовая химия</a></li>
			          		<li class="<?=$it04?>"><a href="item04.php">Косметика</a></li>
			          		<li class="<?=$it05?>"><a href="item05.php">Одежда и аксессуары</a></li>
		          		</ul>
		        	</li>
		        	<li><a href="adress.php" class="<?=$adress?>">Адрес</a></li>
		        </ul>
		    </div>
	    </div>
	</div>
</div>