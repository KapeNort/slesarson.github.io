<div id="banner" style="margin-top: 40px;">

	<div class="container">

		<h1 style="padding-top: 0"> <?=$title?> </h1>

		<div class="row">

			<div class="col-md-6 col-xs-12"> 

				<img src="<?=$img?>" width="100%" height="auto" class="borderwhite" style="margin-bottom: 20px" alt="">	

			</div>

			<div class="col-md-6 col-xs-12">

				<p > <?=$text?> </p>

			</div>

		</div>

	</div>

</div>