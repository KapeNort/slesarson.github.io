<div id="headerwrap">
	<div class="container">
		<div class="row kek">
			<div class="col-md-6  col-xs-6">
			<a href="index.php"><img src="Img/Logo.png" class="logo" alt="" ></a>
			</div>
			<div class="col-md-6 col-xs-6">
				<p class="text-right white">г.Электросталь <br> ул.Ялагина д.26</p>
			</div>
		</div>
	</div>
</div>