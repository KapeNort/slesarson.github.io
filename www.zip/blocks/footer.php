<div id="headerwrap" class="footer">
	<div class="container">
		<div class="row centered" >

			<p>Всё для кройки и шитья, бытовые товары, одежда и аксессуары. <br>г.Электросталь ул.Ялагина д.26</p>
			
		</div>
	</div>
</div>