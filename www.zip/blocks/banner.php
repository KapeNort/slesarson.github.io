<div  class="banner">
	<div class="container" style="">
		<div class="row" style="/**display: flex; align-items: center;">
			<div class="col-md-6 col-xs-6">

				<h1 style="padding-bottom: 20px;">Добро пожаловать!</h1>

				<p class="text" style="color:; padding: 5px; margin-bottom: 30px; font-weight: bold ;"> Мы - магазин товаров для дома, шитья и рукоделия. У нас представлен широкий выбор швейной фурнитуры, все виды батареек, а к зимнему сезону мы пополнили наш ассортимент теплыми женскими, мужскими и детскими шапками! Отличное качество по недорогой цене. Приходите и убедитесь в этом сами! </p>
				
			</div>
		</div>
	</div>
</div>