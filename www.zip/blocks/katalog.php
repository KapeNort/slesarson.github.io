<div class="container" >
  <div class="row centered">
    <div class="col-md-4 col-xs-12" >

      <h3 >Швейная фурнитура</h3>

      <div class="row">

        <div class="col-xs-6 col-md-12">
          <a href="item01.php"><img class="price" src="Img/shvey.jpg" width="100%" height="auto" alt=""></a>
        </div>

        <div class="col-xs-6 col-md-12">
          <p>Вашему вниманию предлагаются различные товары для кройки, шитья и других видов творчества. Широкий выбор мулине, пряжи и бисера, молнии и атласные ленты, схемы для вышивания (как бисером, так и мулине), спицы и иголки.</p>
        </div>
      </div>

    </div>
    <div class="col-md-4 col-xs-12">

      <h3>Товары для дома</h3>

      <div class="row">

        <div class="col-xs-6 col-md-12">
          <a href="item02.php"><img class="price" src="Img/batar.jpg" width="100%" height="auto" alt=""></a>
        </div> 

        <div class="col-xs-6 col-md-12">

          <p>Разнообразие скатертей, клеенок и полотенец поможет сделать ваш дом еще более уютным. Так же у нас вы найдете батарейки различных типов. В наличии пальчиковые, мизинчиковые батарейки, батарейки типов крона, R20, R24, таблектки (в том числе и CR2032).</p>

        </div>
      </div>
    </div>

      <div class="col-md-4 col-xs-12">

        <h3>Одежда</h3>

        <div class="row">

          <div class="col-xs-6 col-md-12">

            <a href="item05.php"><img class="price" src="Img/store.jpg" width="100%" height="auto" alt=""></a>

          </div>

          <div class="col-xs-6 col-md-12">

           <p>Мы предлагаем вашему выбору женские, детские и мужские теплые шапки. Для мужчин представлен широкий перечень верхней одежды даже самых больших размеров (48-60). Рубашки, джемпера, футболки и куртки по доступным ценам!</p>

          </div>
        </div>
      </div>
    </div>
</div>


<div class="container">

  <div class="row centered">

    <div class="col-md-offset-2 col-md-4 col-xs-12" >

      <h3 >Бытовая химия</h3>

      <div class="row">

        <div class="col-xs-6 col-md-12">

          <a href="item03.php"><img class="price" src="Img/chemy1.jpg" width="100%" height="auto" alt=""> </a>

        </div>

        <div class="col-xs-6 col-md-12">

          <p> Всё для чистоты и порядка в доме. Моющие средства, стиральные порошки, освежители воздуха. У нас вы можете купить шампуни, гели для душа и другие средства личной гигиены. Высокое качество от лучших поставщиков!</p>

        </div>

      </div>
    </div>

    <div class="col-md-4 col-xs-12">

      <h3>Косметика</h3>

      <div class="row">

        <div class="col-xs-6 col-md-12">

          <a href="item04.php"><img class="price" src="Img/make1.jpg" width="100%" height="auto" alt=""></a>

        </div>

        <div class="col-xs-6 col-md-12">

          <p> С каждым днём всё больше популярности приобретают товары из Белоруссии. В нашем магазине представлена лучшая Белорусская косметика, туалетная вода и духи. Продукцию лушчих производителей Вы можете купить по приемлемым и доступным ценам. Оставайте всегда красивыми вместе с нами! </p>

        </div>

      </div>

    </div>

  </div>

</div>