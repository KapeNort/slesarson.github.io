<div id="banner" style="margin-top: 40px;">
  <div class="container">
    <div class="row">
    <div class="col-md-6 col-xs-12"> 

    <!--<img src="Img/image.jpg" width="100%" height="auto" class="borderwhite" style="margin-bottom: 20px" alt="">-->

    <div class="borderwhite"><iframe src="https://yandex.ru/map-widget/v1/?um=constructor%3A4498d6b299e9cb4a97891ab0c0f9b76f0d144e669a2d8de24b6ef89276a7e10e&amp;source=constructor" width="100%" height="250px" frameborder="0"></iframe></div>

    </div>
      <div class="col-md-6 col-xs-12">

        <p class="text-center"> <?=$text?> </p>
        
      </div>
    </div>
  </div>
</div>